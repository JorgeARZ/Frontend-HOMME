import axios from 'axios';
import FormData from 'form-data'
import { useState } from "react";
import DatePicker,{DateObject} from "react-multi-date-picker"
import TimePicker from "react-multi-date-picker/plugins/time_picker";
import "react-datepicker/dist/react-datepicker.css";
import useHydrodynamic from '../hooks/useHidrodinamyc';
// import Alerta from './Alerta';


const Form = () => {

  //codigo FUNCIONAL SOLO FALTA EL TEMA DEL A HORA

    //EXTRAYENDO DATOS DEL CONTEXT HYDRODINAMY
    const {handleChangeDatos,datos,SubmitHydro} = useHydrodynamic()
  

     const EnviarDatos = e =>{
      e.preventDefault()

      if(Object.values(datos).includes('')){
      console.log('todo los campos son obligatorios')
        return
    }   
      //Submit Hidro Axios request Post formulario
        SubmitHydro([datos])
    }

  return (
    <>
    <form onSubmit={EnviarDatos}>

    {/* <DatePicker   
        value={datos.fechaInicio}
        onOpen={() => setDatos(new DateObject().toUTC())}
        onChange={e => handleChangeDatos(e)}
        format="YYYY-MM-DD HH:MM:ss"
        placeholder="please select date"
        plugins={[<TimePicker position="right" hideSeconds header={false} />]}
        name='fechaInicio'
      />
       <DatePicker
        value={datos.fechaInicio}
        onOpen={() => setDatos(new DateObject().toUTC())}
        onChange={e => handleChangeDatos(e)}
        format="YYYY-MM-DD HH:MM:ss"
        placeholder="please select date"
        plugins={[<TimePicker position="right" hideSeconds header={false} />]}
        name='fechaTermino'
      /> */}

          <input type="date" placeholder='Fecha Inicio' className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg  block w-full p-2.5"
           value={datos.fechaInicio}
           name="fechaInicio"
           onChange={e => handleChangeDatos(e)} /> 
           <input type="date" placeholder='Fecha Termino' className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg  block w-full p-2.5"
           value={datos.fechaTermino}
           name="fechaTermino"
           onChange={e => handleChangeDatos(e)} /> 

                        <div>
                            <label htmlFor="name" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">User</label>
                            <input type="text" name="latitudNorte" id="latitudNorte" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg  block w-full p-2.5" placeholder="latitudNorte" required="" 
                            value={datos.latitudNorte}
                            onChange={e => handleChangeDatos(e)}
                            />
                        </div>
                        <div>
                            <label htmlFor="name" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">User</label>
                            <input type="text" name="latitudSur" id="latitudSur" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg  block w-full p-2.5" placeholder="latitudSur" required="" 
                            value={datos.latitudSur}
                            onChange={e => handleChangeDatos(e)}
                            />
                            </div>
                                           <div>
                            <label htmlFor="name" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">User</label>
                            <input type="text" name="longitudOriente" id="longitudOriente" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg  block w-full p-2.5" placeholder="longitudOriente" required="" 
                            value={datos.longitudOriente}
                            onChange={e => handleChangeDatos(e)}
                            />
                            </div>
                                           <div>
                            <label htmlFor="name" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">User</label>
                            <input type="text" name="longitudPoniente" id="longitudPoniente" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg  block w-full p-2.5" placeholder="longitudPoniente" required="" 
                            value={datos.longitudPoniente}
                            onChange={e =>handleChangeDatos(e)}
                            />
                        </div>

                        <div>
                            <label htmlFor="name" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">User</label>
                            <input type="text" name="local" id="local" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg  block w-full p-2.5" placeholder="local" required="" 
                            value={datos.local}
                            onChange={e => handleChangeDatos(e)}
                            />
                        </div>
                        <input type="submit" className="w-full text-black bg-white hover:bg-red-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center" />
    
    </form>
    </>
  )
}

export default Form