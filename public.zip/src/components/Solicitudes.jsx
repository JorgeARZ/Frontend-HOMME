
const Solicitudes = ({data}) => {
// Lee bien la data
console.log(data)
const {user,_id,requestStatus} = data
  return (
//     //no me muestra
    <>
    <span>{user}</span>
    {/* <span>{_id}</span>
    <span>{requestStatus}</span> */}
    <span>asdsaddas</span>
</>
  )
}

export default Solicitudes
