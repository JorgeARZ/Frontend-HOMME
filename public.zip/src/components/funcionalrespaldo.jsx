  // const [fechaInicio, setfechaInicio] = useState();
    // const [fechaTermino, setFechaTermino] = useState();
    //  const [latitudNorte,setlatitudNorte] = useState('')
    //  const [latitudSur,setlatitudSur] = useState('')
    //  const [longitudOriente,setlongitudOriente] = useState('')
    //  const [longitudPoniente,setlongitudPoniente] = useState('')
    //  const [local,setLocal] = useState(true)

    //  const {SaveHidro} = useHydrodynamic()
    //  console.log(SaveHidro)


     //     e.preventDefault()
    //     const token = localStorage.getItem('token')
    //     let data = new FormData();
    //     data.append('fechaInicio', fechaInicio);
    //     data.append('fechaTermino', fechaTermino);
    //     data.append('latitudNorte', latitudNorte);
    //     data.append('latitudSur', latitudSur);
    //     data.append('longitudOriente',longitudOriente);
    //     data.append('longitudPoniente',longitudPoniente);
    //     data.append('local', local);

    //     let config = {
    //       method: 'post',
    //         maxBodyLength: Infinity,
    //          url: 'http://34.176.175.133:3000/modeling/hidrodinamic',
    //         headers: { 
    //            'x-token': token, 
    //           //   ...data.getHeaders()
    //          },
    //           data : data

            
    //        };
        
    //        axios.request(config)
    //       .then((response) => {
    //         console.log(JSON.stringify(response.data));
    //        })
    //       .catch((error) => {
    //          console.log(error);
    //       });
